/*
  Pot.cpp - Library for potentiometer handling
  Created by Matthias Schmidt, 11.01.2019
*/

#include <Pot.h>

Pot::Pot(byte pin) {
  _pin = pin;
}

Pot::Pot(byte pin, uint16_t segments) {
  _pin = pin;
  setSeg(segments);
}

Pot::Pot(byte pin, uint16_t segments, bool fast) {
  _pin = pin;
  setSeg(segments);
  _fast = fast;
}

void Pot::begin() {
  if (_fast == true) {
#if FASTADC
    // set prescale to 16 => FAST MOOOOOOODE!!!!
    sbi(ADCSRA, ADPS2);
    cbi(ADCSRA, ADPS1);
    cbi(ADCSRA, ADPS0);
#endif
  }
  pinMode(_pin, INPUT);
}

void Pot::setSeg(uint16_t toThis) {
  _div = 1024 / constrain(toThis, 1, 1024);
}

uint16_t Pot::getVal() {
  return analogRead(_pin);
}

uint16_t Pot::getSeg() {
  return getVal() / _div;
}