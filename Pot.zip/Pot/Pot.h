/*
  Pot.h - Library for potentiometer handling
  Created by Matthias Schmidt, 11.01.2019
*/

#ifndef Pot_H
#define Pot_H
#include <Arduino.h>

#define FASTADC 1
#ifndef cbi
#define cbi(sfr, bit) (_SFR_BYTE(sfr) &= ~_BV(bit))
#endif
#ifndef sbi
#define sbi(sfr, bit) (_SFR_BYTE(sfr) |= _BV(bit))
#endif

class Pot {
	public:
		Pot(byte pin);
		Pot(byte pin, uint16_t div);
		Pot(byte pin, uint16_t div, bool fast);
        void begin();
        void setSeg(uint16_t toThis);
		uint16_t getVal();
		uint16_t getSeg();		
	private:
		byte _pin;
		uint16_t _div = 8; //number of Segments = 1024/div => defaults to 128 Segments
		bool _fast = true; //faster analogRead() => default for now (slow may be more precise?)
};

#endif